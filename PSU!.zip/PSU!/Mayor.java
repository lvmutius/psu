import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Mayor extends Politician {

    //I elected to not have a secondary constructor that takes in a String name
    //because since we only intend to have one mayor, one governor, one Trump, 
    //we don't need to worry about that. It simplifies the code. Hence,
    //the getName() method just returns a fixed name.


    //Ok... I think I figured out the static problem. I was trying to make static changes to mayor (Mayor.health = super.health * MODIFIER)
    //and I was also trying to make a "static reference" (System.out.println(Mayor.health) rather than
    //trying to make a specific reference to a mayor (System.out.println(mayorDouglas.health))

    private static final double MAYOR_MODIFIER = 1.2; //all of the parent class's stats except precision and evasion are scaled by this modifier for this class, making this character stronger

    public Mayor(){
        health = super.health * MAYOR_MODIFIER;
        maxHealth = health;
        attack = super.attack * MAYOR_MODIFIER;
        defense = super.defense * MAYOR_MODIFIER;
        speed = super.speed * MAYOR_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;

        attack1 = new Dmg("weak", "Incisive Twitter Remark");
        attack2 = new StatEnemy("weak", "attack", "Well-Positioned Campaign Billboard");
        attack3 = new Dmg("weak", "Fake iMessage Leak");
        attack4 = new StatSelf("weak", "defense", "Mobile Propaganda Car");
    }

    //Non customizable.
    public String getName(){
        return "Mayor Douglas";
    }

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("doug.png"));
        } catch (IOException e){
        }
        return image;
    }

    public double getMaxHealth(){
        return this.maxHealth;
    }

    public void setHealthBar(){
        this.healthBar = new HealthBar(this);
    }     
    
    public void setButtons(Combat combat){
        this.buttons = new Buttons(this, combat);
    }

    public void resetStats(){
        health = super.health * MAYOR_MODIFIER;
        maxHealth = health;
        attack = super.attack * MAYOR_MODIFIER;
        defense = super.defense * MAYOR_MODIFIER;
        speed = super.speed * MAYOR_MODIFIER;
        precision = super.precision; 
        evasion = super.evasion;
    }
}
