import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Governor extends Politician {
 
    private static final double GOVERNOR_MODIFIER = 1.4; //all of the parent class's stats except precision and evasion are scaled by this modifier for this class, making this character stronger

    public Governor(){
        health = super.health * GOVERNOR_MODIFIER;
        maxHealth = health;
        attack = super.attack * GOVERNOR_MODIFIER;
        defense = super.defense * GOVERNOR_MODIFIER;
        speed = super.speed * GOVERNOR_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;

        attack1 = new Dmg("medium", "Slander, Defame, Lie");
        attack2 = new StatSelf("weak", "evasion", "Masterful Diffusion of Allegations");
        attack3 = new StatSelf("medium", "precision", "Let's Find Some Dirt On Them...");
        attack4 = new StatSelf("strong", "speed", "Campaign on Social Media");
    }

    //Non customizable.
    public String getName(){
        return "Governor Abraham";
    }

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("arnold.png"));
        } catch (IOException e){
        }
        return image;
    }

    public void setHealthBar(){
        this.healthBar = new HealthBar(this);
    }     
    
    public void setButtons(Combat combat){
        this.buttons = new Buttons(this, combat);
    }

    public double getMaxHealth(){
        return this.maxHealth;
    }
    
    public void resetStats(){
        health = super.health * GOVERNOR_MODIFIER;
        maxHealth = health;
        attack = super.attack * GOVERNOR_MODIFIER;
        defense = super.defense * GOVERNOR_MODIFIER;
        speed = super.speed * GOVERNOR_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;
    }
}
