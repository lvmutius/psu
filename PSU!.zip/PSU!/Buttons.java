import javax.swing.plaf.basic.BasicInternalFrameTitlePane.CloseAction;

import java.awt.*;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Buttons {
    private JFrame frame;
    private JTextArea commentator;
    private JButton[] buttonsArray;
    private Politician politician;
    public ButtonListener listener;
    public Combat combat;

    public Buttons(Politician politician, Combat combat) {
        this.politician = politician;
        this.combat = combat;
        frame = PSUMain.getFrame();
        commentator = PSUMain.getCommentator();

        setButtons();
    }

    public void setButtons() {
        buttonsArray = new JButton[4]; // Creates an array of 4 attack buttons
        buttonsArray[0] = new JButton(politician.getAttack1Name());
        buttonsArray[1] = new JButton(politician.getAttack2Name());
        buttonsArray[2] = new JButton(politician.getAttack3Name());
        buttonsArray[3] = new JButton(politician.getAttack4Name());
        listener = new ButtonListener(buttonsArray, politician, combat); // creates an action listener for
                                                                                // attackButtons
        if (politician.getName() == "Candidate Alex") {
            int buttonY = (int) (PSUMain.JWIDTH / 2.5); // This is the initial y coordinate
            for (int i = 0; i < buttonsArray.length; i++) {
                frame.add(buttonsArray[i]); // adds the buttons
                buttonsArray[i].setBounds(PSUMain.JWIDTH / 24, buttonY, PSUMain.JWIDTH / 4, 40); // We can adjust these values to fit in any size frames
                buttonsArray[i].addActionListener(listener); // Adds the action listener to each button
                buttonY += 50; // Increments the y coordinate of the buttons by 50
            }
        } else {
            int buttonY = (int) (PSUMain.JWIDTH / 2.5); // This is the initial y coordinate
            for (int i = 0; i < buttonsArray.length; i++) {
                frame.add(buttonsArray[i]);
                buttonsArray[i].setBounds(PSUMain.JWIDTH - (PSUMain.JWIDTH / 4 + PSUMain.JWIDTH / 24), buttonY, PSUMain.JWIDTH / 4, 40);
                buttonsArray[i].addActionListener(listener);
                buttonY += 50;
            }
        }
    }
}