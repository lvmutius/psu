import java.awt.image.BufferedImage;

public abstract class GridObject {
    public String[] img;

    public abstract BufferedImage getImage();

    public abstract String getName();
}
