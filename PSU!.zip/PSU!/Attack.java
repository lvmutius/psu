public abstract class Attack extends GridObject {
    

    //attack name
    private String name;

    //attack attributes
    //note: cannot be static (each attack must have independent attributes), cannot be private (else child classes cannot edit them)
    protected boolean isDamageType; //Damage-Type Attacks do damage (isDamageType == true), Stat-Type attacks alter stats attacks alter stats
    protected boolean isStatSelf; // Stat-Self is a subtype of Stat-Type attacks. Stat-self attacks are directed at the attacker's stats (e.x. boost evasion, boost attack). (isStatSelf == true). Stat-Enemy attacks are directed at the defender's stats (isStatSelf == false)
    protected String statName; //String used to refer to what kind of stat is altered by a Stat-type attak (e.x. "attack" or "evasion")
    protected double baseDamage; //base damage of the move itself, used in the calculation for total damage output
    protected double baseAccuracy; //base accuracy of the move itself, used in the calculation that checks if an attack connects
    protected double attModifier; //attack modifier, used in Stat-Type moves (Stat-Type moves are used to alter both own and enemy's stat)
    protected double defModifier; //defense modifier, used in Stat-Type moves (Stat-Type moves are used to alter both own and enemy's stat)
    protected double spdModifier; //speed modifier, used in Stat-Type moves (Stat-Type moves are used to alter both own and enemy's stat)
    protected double prsModifier; //precision modifier, used in Stat-Type moves (Stat-Type moves are used to alter both own and enemy's stat)
    protected double evaModifier; //evasion modifier, used in Stat-Type moves (Stat-Type moves are used to alter both own and enemy's stat)

    //base constructor method
    public Attack(){
        isDamageType = true; //initialization
        isStatSelf = false;
        if (isDamageType = true) isStatSelf = false; //ensures that damage-type attacks are never Stat-Self. Helpful to avoid bugs in code.
        statName = null; //should be set to one of "att", "def", "spd", etc. for Stat-Type moves
        baseDamage = 10.0; //in healthpoints
        baseAccuracy = 1.0;
        attModifier = 1.0;
        defModifier = 1.0;
        spdModifier = 1.0;
        prsModifier = 1.0;
        evaModifier = 1.0;
    }
    //constructor that takes in name
    public Attack(String name){
        this.name = name; //sets name of move

        isDamageType = true; //initialization
        isStatSelf = false;
        if (isDamageType = true) isStatSelf = false; //ensures that damage-type attacks are never Stat-Self
        statName = null; //should be set to one of "att", "def", "spd", etc. for Stat-Type moves
        baseDamage = 10.0; //in healthpoints
        baseAccuracy = 1.0;
        attModifier = 1.0;
        defModifier = 1.0;
        spdModifier = 1.0;
        prsModifier = 1.0;
        evaModifier = 1.0;
    }
    
    public String getName(){
        return name;
    }

    public boolean isDamageType() {
        return isDamageType;
    }

    public boolean isStatSelf() {
        return isStatSelf;
    }

    public String getStatName(){
        return statName;
    }
    
    public double getBaseDamage(){
        return baseDamage;
    }
    
    public double getBaseAccuracy(){
        return baseAccuracy;
    }

    public double getAttModifier(){
        return attModifier;
    }

    public double getDefModifier(){
        return defModifier;
    }

    public double getSpdModifier(){
        return spdModifier;
    }

    public double getPrsModifier(){
        return prsModifier;
    }

    public double getEvaModifier(){
        return evaModifier;
    }
}