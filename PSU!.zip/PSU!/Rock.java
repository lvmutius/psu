import java.util.Scanner;
import java.io.File;

import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

import java.io.IOException;

public class Rock extends GridObject {
    public BufferedImage image;
    public String img = "Rock";

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("Rock.png"));
        } catch (IOException e){
        }
        return image;
    }

    public String getName(){
        return "Grass";
    }
}
