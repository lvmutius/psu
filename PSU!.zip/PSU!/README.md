Welcome to Political Showdown: Ultimate!

This is a CPSC112 (Spring 2022) Final Project by Leonardo von Mutius, Aly Moosa, Liam Varela, and Emir Buyukhanli.

In PSU!, you play as Alex, an aspiring politician who looks remarkably similar to Zuko (of Last Airbender notoriety). In order to rise through the ranks and become the ultimate politician, you must defeat all who stand in your way—Mayor, Governor, and Trump!

Once you defeat Trump, the game is completed! (Unfortunately, we had problems with the win screen in this release... A win screen will be patched in in a future release!)

To play, you must open PSU in your IDE, compile PSUMain.java, and run the game. Make sure you have the appropriate Java extensions installed. To reset the game, recompile PSUMain.java, and run the game again!

Thank you, and enjoy! :))))
