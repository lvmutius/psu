import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.awt.event.KeyEvent;
import javax.imageio.ImageIO;
import java.awt.event.KeyListener;
import java.lang.Thread;

public class PSUMain {
    // for overworld
    public static final int WIDTH = 700;
    public static final int HEIGHT = 700;
    public static final int CELL_WIDTH = 20;
    public static final int CELL_HEIGHT = 20;

    public static int cellPixelHeight = HEIGHT / CELL_HEIGHT;
    public static int cellPixelWidth = WIDTH / CELL_WIDTH;
    public static GridObject[][] grid = new GridObject[CELL_WIDTH][CELL_HEIGHT];
    public static int mayorX, mayorY, governorX, governorY, trumpX, trumpY, playerX = 10, playerY = 10;
    public static DrawingPanel panel = new DrawingPanel(WIDTH, HEIGHT);
    public static BufferedImage offscreen = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
    public static Graphics2D osg = offscreen.createGraphics();
    public static Graphics2D g = panel.getGraphics();
    public static BufferedImage bg;
    public static BufferedImage image;
    public static Random rand = new Random();
    public static boolean inFight = false;
    public static boolean inGame;
    public static File background = new File("bg.jpg");
    public final static int DELAY = 200; // in miliseconds

    public static JFrame frame1 = new JFrame();
    public static JFrame frame2 = new JFrame();
    public static JFrame frame3 = new JFrame();

    public static JTextArea commentator1 = new JTextArea(50, 200);
    public static JTextArea commentator2 = new JTextArea(50, 200);
    public static JTextArea commentator3 = new JTextArea(50, 200);

    // not sure if making these static will break code. what does it mean to make
    // them static?
    public static Politician player;
    public static Politician mayor;
    public static Politician governor;
    public static Politician trump;

    public static Combat mayorCombat;
    public static Combat governorCombat;
    public static Combat trumpCombat;

    public static boolean mayorDefeated = false;
    public static boolean governorDefeated = false;
    public static boolean trumpDefeated = false;

    // for JFrame
    public static final int JWIDTH = 1440;
    public static final int JHEIGHT = 1000;

    public static void main(String[] args) throws IOException {
        player = new Player();
        mayor = new Mayor();
        governor = new Governor();
        trump = new Trump();

        osg.setColor(Color.GREEN);
        osg.fillRect(0, 0, WIDTH, HEIGHT);
        osg.setColor(Color.BLACK);
        // osg.drawString("Welcome!", WIDTH / 3, HEIGHT / 3);
        // osg.drawString("You ", x, y);
        initializeGrid();
        try {
            drawGrid();
        } catch (IOException e) {
            e.printStackTrace();
        }
        drawPlayer(player);
        setKeys(panel);
        g.drawImage(offscreen, 0, 0, null);
        while (!inFight) {
            drawPlayer(player);
        }
        g.drawImage(offscreen, 0, 0, null);
    }

    public static void initializeGrid() {
        inGame = true;
        for (int i = 0; i < CELL_WIDTH; i++) {
            for (int j = 0; j < CELL_HEIGHT; j++) {
                if (Math.random() < 0.2)
                    grid[i][j] = new Grass();
                else if (Math.random() < 0.25)
                    grid[i][j] = new Rock();
                else
                    grid[i][j] = new Empty();
            }
        }
        mayorX = rand.nextInt(CELL_WIDTH);
        mayorY = rand.nextInt(CELL_HEIGHT);
        governorX = rand.nextInt(CELL_WIDTH);
        governorY = rand.nextInt(CELL_HEIGHT);
        trumpX = rand.nextInt(CELL_WIDTH);
        trumpY = rand.nextInt(CELL_HEIGHT);
        playerX = rand.nextInt(CELL_WIDTH);
        playerY = rand.nextInt(CELL_HEIGHT);
        while (grid[playerX][playerY].toString().contains("Rock")) {
            playerX = rand.nextInt(CELL_WIDTH);
            playerY = rand.nextInt(CELL_HEIGHT);
        }
        grid[mayorX][mayorY] = mayor;
        grid[governorX][governorY] = governor;
        grid[trumpX][trumpY] = trump;

    }

    public static void drawGrid() throws IOException {
        for (int i = 0; i < CELL_WIDTH; i++) {
            for (int j = 0; j < CELL_HEIGHT; j++) {
                osg.drawImage((grid[i][j]).getImage(), i * cellPixelWidth, j * cellPixelHeight, cellPixelWidth,
                        cellPixelHeight, null);
            }
        }
        bg = offscreen;
        ImageIO.write(bg, "JPEG", background);
    }

    public static void drawPlayer(Politician player) {
        osg.drawImage(player.getImage(), playerX * cellPixelWidth, playerY * cellPixelHeight, cellPixelWidth,
                cellPixelHeight, null);
    }

    public static void setKeys(DrawingPanel panel) {
        KeyListener listener = new arrowKeyListener(panel);
        panel.addKeyListener(listener);
        System.out.println(playerX);
    }

    public GridObject checkLeft() {
        System.out.print(grid[playerX - 1][playerY].toString());
        return grid[playerX - 1][playerY];
    }

    public GridObject checkRight() {
        System.out.print(grid[playerX + 1][playerY].toString());
        return grid[playerX + 1][playerY];
    }

    public GridObject checkUp() {
        System.out.print(grid[playerX][playerY - 1].toString());
        return grid[playerX][playerY - 1];
    }

    public GridObject checkDown() {
        System.out.print(grid[playerX][playerY + 1].toString());
        return grid[playerX][playerY + 1];
    }

    public void checkFights() throws IOException {
        if (grid[playerX][playerY].getName() == "Mayor Douglas" && canFightMayor()) {
            System.out.println("Fight initiated with Mayor Douglas.");
            doMayorCombat(frame1, commentator1, player, mayor);
            mayorDefeated = true;
            // player.resetStats();
            System.out.println(player.health);
            System.out.println(player.attack);

                   
        }
         else if (grid[playerX][playerY].getName() == "Governor Abraham" && canFightGov()) {
            System.out.println("Fight initiated with Governor Abraham.");
            doGovernorCombat(frame2, commentator2, player, governor);
            governorDefeated = true;
            // player.resetStats();
            
            
        }
        else if (grid[playerX][playerY].getName() == "Donald Trump" && canFightTrump()) {
            System.out.println("Fight initiated with Orange Man.");
            doTrumpCombat(frame3, commentator3, player, trump); 
            trumpDefeated = true;
        } 
    
    }

    public static void doMayorCombat(JFrame frame, JTextArea commentator, Politician player, Politician opponent) throws IOException {
        // frame = new JFrame();
        System.out.println();
        System.out.println(frame == null);
        setJFrame(frame); // potential bug: the frames have already been created... is that ok?
        setCommentator(frame, commentator);
        mayorCombat = new Combat(player, opponent, frame, commentator);
        player.setHealthBar();
        player.setButtons(mayorCombat);
        opponent.setHealthBar();
        opponent.setButtons(mayorCombat);

        // set sprite
        BufferedImage myPicture = ImageIO.read(new File("zuko.png"));
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        picLabel.setBounds(124, 100, 250, 500);
        frame.add(picLabel);

        // set sprite
        BufferedImage myPicture2 = ImageIO.read(new File("doug.png"));
        JLabel picLabel2 = new JLabel(new ImageIcon(myPicture2));
        picLabel2.setBounds(1050, 100, 250, 500);
        frame.add(picLabel2);

        //combat
        frame.setVisible(true); // make frame visible
    }

    public static void doGovernorCombat(JFrame frame, JTextArea commentator, Politician player, Politician opponent) throws IOException {
        System.out.println();
        setJFrame(frame); // potential bug: the frames have already been created... is that ok?
        setCommentator(frame, commentator);
        governorCombat = new Combat(player, opponent, frame, commentator);
        player.setHealthBar();
        player.setButtons(governorCombat);
        opponent.setHealthBar();
        opponent.setButtons(governorCombat);

        // set sprite
        BufferedImage myPicture = ImageIO.read(new File("zuko.png"));
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        picLabel.setBounds(124, 100, 250, 500);
        frame.add(picLabel);

        // set sprite
        BufferedImage myPicture2 = ImageIO.read(new File("arnold.png"));
        JLabel picLabel2 = new JLabel(new ImageIcon(myPicture2));
        picLabel2.setBounds(1050, 120, 300, 400);
        frame.add(picLabel2);

        //combat
        frame.setVisible(true); // make frame visible
    }

    public static void doTrumpCombat(JFrame frame, JTextArea commentator, Politician player, Politician opponent) throws IOException {
        System.out.println();
        setJFrame(frame); // potential bug: the frames have already been created... is that ok?
        setCommentator(frame, commentator);
        trumpCombat = new Combat(player, opponent, frame, commentator);
        player.setHealthBar();
        player.setButtons(trumpCombat);
        opponent.setHealthBar();
        opponent.setButtons(trumpCombat);

        // set sprite
        BufferedImage myPicture = ImageIO.read(new File("zuko.png"));
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        picLabel.setBounds(124, 100, 250, 500);
        frame.add(picLabel);

        // set sprite
        BufferedImage myPicture2 = ImageIO.read(new File("DonaldTrump.png"));
        JLabel picLabel2 = new JLabel(new ImageIcon(myPicture2));
        picLabel2.setBounds(1080, 200, 275, 300);
        frame.add(picLabel2);
        frame.setVisible(true); // make frame visible
    }



    private static void setJFrame(JFrame frame) {
        // frame.setDefaultCloseOperation(frame1.EXIT_ON_CLOSE);
        frame.setSize(JWIDTH, JHEIGHT);
        frame.setLayout(null);
    }

    private static void setCommentator(JFrame frame, JTextArea commentator) {
        commentator.setBounds((JWIDTH / 3), (int) (JWIDTH / 2.5), (JWIDTH / 3), (JHEIGHT / 6));
        frame.add(commentator);
    }

    public boolean canFightMayor() {
        if (!(mayorDefeated) && !(governorDefeated) && !(trumpDefeated)) {
            return true;
        } else
            return false;
    }

    public boolean canFightGov() {
        if ((mayorDefeated) && !(governorDefeated) && !(trumpDefeated)) {
            return true;
        } else
            return false;
    }

    public boolean canFightTrump() {
        if ((mayorDefeated) && (governorDefeated) && !(trumpDefeated)) {
            return true;
        } else
            return false;
    }

    public static JFrame getFrame() {
        if (!(mayorDefeated) && !(governorDefeated) && !(trumpDefeated)) {
            return frame1;
        } else if (mayorDefeated && !(governorDefeated) && !(trumpDefeated)) {
            return frame2;
        } else if (mayorDefeated && (governorDefeated) && !(trumpDefeated)) {
            return frame3;
        } else {
            System.out.println("ERROR: ___defeated booleans not set properly.");
            return frame1; // how do I do a try catch here?
        }
    }

    public static JTextArea getCommentator() {
        if (!(mayorDefeated) && !(governorDefeated) && !(trumpDefeated)) {
            return commentator1;
        } else if (mayorDefeated && !(governorDefeated) && !(trumpDefeated)) {
            return commentator2;
        } else if (mayorDefeated && (governorDefeated) && !(trumpDefeated)) {
            return commentator3;
        } else {
            System.out.println("ERROR: ___defeated booleans not set properly.");
            return commentator1; // how do I do a try catch here?
        }
    }

    public BufferedImage getBackgroundImage() {
        try {
            return image = ImageIO.read(background);
        } catch (IOException e) {
        }
        return image;
    }

    // // general scaling method
    // public static double scale(double oldValue, double oldMin, double oldMax, double newMin, double newMax) {
    //     return (((oldValue - oldMin) / (oldMax - oldMin)) * (newMax - newMin) + newMin);
    // }

    // // helper function since we have multiple places where you will scale the
    // // sprites to panel & cell size
    // public static int scaleToPanel(double oldValue) {
    //     return (int) (scale(oldValue, -CELL_WIDTH, CELL_WIDTH, 0, WIDTH));
    // }
    // public void displayWinScreen() throws IOException {
    //     BufferedImage gameWinner = ImageIO.read(new File ("winner.jpg"));
    //     osg.drawImage(gameWinner, null, 0 ,0);
    //     g.drawImage(offscreen, null, 0, 0);
    // }   
    // public void displayLoseScreen() throws IOException {
    //     BufferedImage gameover = ImageIO.read(new File("gameover.jpg"));
    //     osg.drawImage(gameover, null, 0, 0);
    //     g.drawImage(offscreen, null, 0, 0);
    // }   

}
