import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Combat {

    static boolean attackSuccess; //can be static?
    protected JTextArea commentator;
    public JFrame frame;
    protected Politician player;
    protected Politician p2;
    protected Politician turn;
    private double damageOutput;
    public boolean battleWon;
    public boolean battleLost;
    public enterKeyListener listener;

    public Combat(Politician player, Politician p2, JFrame frame, JTextArea commentator){
        this.player = player;
        this.p2 = p2;
        this.frame = frame;
        this.commentator = commentator;
        this.turn = getSpeediest(player, p2);
        battleWon = false;
        battleLost = false;

    }
    //RIP doCombat() May 1, 2022 - May 3, 2022

    ///////////////////////////////
    //PRE-COMBAT SEQUENCE METHODS//
    ///////////////////////////////

    //code that determines which of the two combatants in a fight is the quickest.
    public static Politician getSpeediest(Politician p1, Politician p2){
        if (p1.speed >= p2.speed) return p1;
        else return p2;
    }

    //code that determines which of the two combatants in a fight is the slowest.
    public static Politician getSlowest(Politician player, Politician p2){
        if (player.speed >= p2.speed) return p2;
        else return player;
    }

    ///////////////////////////
    //COMBAT SEQUENCE METHODS//
    ///////////////////////////

    //doTurn() handles one turn for one of the Politicians.
    //Its structure is thus:
    //1) Execute initial steps
    //2) Execute checks: Check what kind of move was used, and if it hit or not (if applicable; StatSelf-Type moves ALWAYS hit, unlike Damage-Type and StatEnemy-Type)
    //3) Run the appropriate algorithm
    public void doTurn(Politician attacker, Politician defender, Attack attack){

        /////////////////
        //INITIAL STEPS//
        /////////////////

        //announce attack
        doAttackAnnouncement(attacker, defender, attack);

        //check if attack hit (won't matter for Stat-Self)
        attackSuccess = attackSuccess(attacker, defender, attack);
        System.out.println("//[For debugging] attackSuccess returned " + attackSuccess);

        //////////
        //CHECKS//
        //////////
        //first, determine the type of the attack if it hit
        //second, do the appropriate sequence


        //Check if damage-type AND hit
        if (attack.isDamageType() && attackSuccess){
            //anounce hit
            commentator.append(attacker.getName() + "'s " + attack.getName() + " hit!\n");
            //do turn
            doDamageTypeTurn(attacker, defender, attack);
            //anounce new health
            commentator.append(attack.getName() + " did " + (int) (damageOutput) + " damage!\n");
            commentator.append(defender.getName() + "'s health is now " + (int) defender.getHealth() + ".\n");
            System.out.println(defender.getName() + "'s health is now " + defender.getHealth());
            return;
        } 
        //check if Damage-Type AND Missed
        else if (attack.isDamageType() && !attackSuccess){
            doFailureSequence(attacker, defender, attack);
            return;
        }
        //check if Stat-Enemy-Type and Hit
        else if (!attack.isDamageType() && !attack.isStatSelf() && attackSuccess){
            commentator.append(attacker.getName() + "'s " + attack.getName() + " hit!\n");
            System.out.println(attacker.getName() + "'s " + attack.getName() + " hit!");
            doStatEnemyTypeTurn(attacker, defender, attack);
            commentator.append(defender.getName() + "'s " + attack.getStatName() + " has been lowered!\n"); //Stat-Enemy always lowers stats
            System.out.println(defender.getName() + "'s " + attack.getStatName() + " has been lowered!"); //Stat-Enemy always lowers stats
            return;
        }
        //check if Stat-Enemy-Type and Missed
        else if (!attack.isDamageType() && !attack.isStatSelf() && !attackSuccess){
            doFailureSequence(attacker, defender, attack);
            return;
        }
        //check if Stat-Self; no need to check if hit or miss (attack success) because stat-self always hits
        else if (!attack.isDamageType() && attack.isStatSelf()){
            //don't print out that move hit; Stat-Self-Type moves always hit
            doStatSelfTypeTurn(attacker, attack);
            commentator.append(attacker.getName() + "'s " + attack.getStatName() + " has been raised!\n"); //Stat-Self always raises stats
            System.out.println(attacker.getName() + "'s " + attack.getStatName() + " has been raised!"); //Stat-Self always raises stats
            return;

        } else {
            //for debugging
            commentator.append("...But nothing happened!\n");
            System.out.println("None of the doTurn() if statements succeeded. Likely that attack's variables not fully filled out, or attack.getName() is not properly formatted.\n");
        }
    }

    //This method announces the attacker and the move they used.
    private void doAttackAnnouncement(Politician attacker, Politician defender, Attack attack){
        commentator.append(attacker.getName() + " used " + attack.getName() + "!\n");
    }

    //This method is in charge of the Failure Sequence, a.k.a. what happens when a move misses.
    private void doFailureSequence(Politician attacker, Politician defender, Attack attack){
        commentator.append(attack.getName() + " failed! " + defender.getName() + " is unscathed!\n");
    }

    //This method checks if an attack connects with the oppoent.
    //It works thusly;:
    //1) Attacker's precision (base: 1.0) is multiplied by the Attack's base accuracy (1.0) and subtracted by the enemy's evasion (base: 0.1)
    //2) Math.random checks if the move connects.
    //3) Return the appropriate boolean
    public static boolean attackSuccess(Politician attacker, Politician defender, Attack attack){
        double chance = attacker.precision * attack.getBaseAccuracy() - defender.evasion;
        System.out.println("//[For debugging] Chance of hit is " + chance);
        if (Math.random() < chance) return true;
        else return false;
    }

    //Calculcates damage output and subtracts from defender's health.
    //Should only run if AttackSuccess returned true.
    private void doDamageTypeTurn(Politician attacker, Politician defender, Attack attack){
        damageOutput = attack.getBaseDamage() * (1 + attacker.attack - defender.defense); // bug: doesn't account for extremely high defense RAISING your health
        if (damageOutput < 0) damageOutput = 0;
        defender.health -= damageOutput; //HealthBar class looks at defender health to update itself
    }

    private void doStatSelfTypeTurn(Politician attacker, Attack attack){
        if (attack.getStatName() == "attack"){
            attacker.attack *= attack.getAttModifier();
            return; //necessary?
        }
        else if (attack.getStatName() == "defense"){
            attacker.defense *= attack.getDefModifier();
            return;
        }
        else if (attack.getStatName() == "speed"){
            attacker.speed *= attack.getSpdModifier();
            return;
        }
        else if (attack.getStatName() == "precision"){
            attacker.precision *= attack.getPrsModifier();
            return;
        }
        else if (attack.getStatName() == "evasion"){
            attacker.evasion *= attack.getEvaModifier();
            return;
        }
        //for debugging
        else commentator.append("getStatName() not correctly filled out.");
    }

    private static void doStatEnemyTypeTurn(Politician attacker, Politician defender, Attack attack){
        if (attack.getStatName() == "attack"){
            attacker.attack *= attack.getAttModifier();
            return; //necessary?
        }
        else if (attack.getStatName() == "defense"){
            attacker.defense *= attack.getDefModifier();
            return;
        }
        else if (attack.getStatName() == "speed"){
            attacker.speed *= attack.getSpdModifier();
            return;
        }
        else if (attack.getStatName() == "precision"){
            attacker.precision *= attack.getPrsModifier();
            return;
        }
        else if (attack.getStatName() == "evasion"){
            attacker.evasion *= attack.getEvaModifier();
            return;
        }
        //for debugging
        else System.out.println("getStatName() not correctly filled out.");
    }

    public void doEndingSequence(){
        if (player.getHealth() <= 0){
            commentator.append("You have died! Please exit this window and the start the game over. \n ");
            battleLost = true;
            //draw lose screen
        } else {
            commentator.append("You have vanquished " + p2.getName() + ". \nPlease exit this window to continue.");
            
            player.resetStats();
            battleWon = true;
        }
    }

    public void clearCommentator(){
        commentator.selectAll();
        commentator.replaceSelection("");
    }
    public void updateHealthBars(Politician speediest, Politician slowest){
        speediest.healthBar.updateHealthBar();
        slowest.healthBar.updateHealthBar();
    }

    public void afterButtonClick(Politician attacker, Attack attack){
        Politician defender;
        if (attacker == player){
            defender = p2;
        } else {
            defender = player;
        }
        clearCommentator();
        doTurn(attacker, defender, attack);
        updateHealthBars(attacker, defender);

        if (!(attacker.getHealth() > 0 && defender.getHealth() > 0)){
            doEndingSequence();
            return;
        }
        this.turn = defender;
        
    }

    public Politician getTurn(){
        return this.turn;
    }

}
