import javax.swing.plaf.basic.BasicInternalFrameTitlePane.CloseAction;

import java.awt.*;

import java.awt.Color;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HealthBar {
    private JFrame frame;
    private JTextArea commentator;
    private JProgressBar jProgressBar;
    private Politician politician;
    private double health;
    private double maxHealth;


    private final double ZERO_HEALTH = 0.0;

    public HealthBar(Politician politician) {
        this.politician = politician;
        this.maxHealth = politician.getMaxHealth();
        this.health = maxHealth;

        frame = PSUMain.getFrame();
        commentator = PSUMain.getCommentator();

        setHealthBar();

    }

    public void setHealthBar() {
        System.out.println("Max Health is " + maxHealth);
        jProgressBar = new JProgressBar((int) ZERO_HEALTH, (int) maxHealth);
        frame.add(jProgressBar);
        jProgressBar.setStringPainted(true);
        jProgressBar.setValue((int) politician.getHealth());
        //this code below positions the Health Bar on the frame depending on if the politician passed in is the player, or an enemy
        if (politician.getName() == "Candidate Alex"){ //update to player name later; used "Governor Abraham" for testing
            //set the position to the left side of
            jProgressBar.setBounds(PSUMain.JWIDTH / 24, 100, PSUMain.JWIDTH / 4, 100);
        }
        else {
            jProgressBar.setBounds(PSUMain.JWIDTH - (PSUMain.JWIDTH / 4 + PSUMain.JWIDTH / 24), 100, PSUMain.JWIDTH / 4, 100);
        }
    }

    //test method, unused
    public void testSubtractHealth(Politician politician){
        health = politician.getHealth();
        health -= 50;
    }

    public void updateHealthBar(){
        this.health = politician.getHealth();
        jProgressBar.setValue((int) (health));
    }

}
