import java.awt.image.BufferedImage;

public class StatSelf extends Attack {

    ///////////////////////
    //MODIFIERS EXPLAINED//
    ///////////////////////

    //All of the parent class's stats are scaled according to the chosen strength
    //of a given move. There are 3 kinds of strength: weak, medium, and strong.
    //When creating a move, the first String argument is the strength, and
    //that will determine which of the private static final modifiers below is used.
    //In damage-type moves, base damage is scaled by the modifier. In stat-type
    //moves, (stat-self or stat-enemy), the approprirate stat (indicated by arg 
    //#2 of the constructor, "stat") is used.

    protected static final double WEAK_MODIFIER = 1.2; 
    protected static final double MEDIUM_MODIFIER = 1.4;                       
    protected static final double STRONG_MODIFIER = 1.6;
                                                    
    private static double modifier;
    private String name;

    public StatSelf(String strength, String stat, String name) {

        this.name = name;
        statName =  stat;
        isDamageType = false;
        isStatSelf = true;

        if (strength == "weak")
            modifier = WEAK_MODIFIER;
        else if (strength == "medium")
            modifier = MEDIUM_MODIFIER;
        else if (strength == "strong")
            modifier = STRONG_MODIFIER;
        else { //catch errors
            System.out.println("ERROR: improperly formatted [strength argument] for move '" + name + "'");
            return;
        }

        if (stat == "attack"){
            attModifier *= modifier;
        }
        else if (stat == "defense"){
            defModifier *= modifier;
        }
        else if (stat == "speed"){
            spdModifier *= modifier;
        }
        else if (stat == "precision"){
            prsModifier *= modifier;
        }
        else if (stat == "evasion"){
            evaModifier *= modifier;
        } 
        else {
            System.out.println("ERROR: improperly formatted [stat argument] for move '" + name + "'");
            return;

        }
    }

    public String getName() {
        return name;
    }

    public boolean isDamageType() { //necessary?
        return isDamageType;
    }

    @Override
    public BufferedImage getImage() {
        // TODO Auto-generated method stub
        return null;
    }
}