import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;



public abstract class Politician extends GridObject{
    
    public double maxHealth;
    public double health;
    public double attack;
    public double defense;
    public double speed;
    public double precision;
    public double evasion; 
    public BufferedImage image;

    //should the variables below be private or public? static or not?
    //do I need these as variables? why would I initialize them in the constructor versus up here?
    protected Attack attack1;
    protected Attack attack2;
    protected Attack attack3;
    protected Attack attack4;
    protected HealthBar healthBar;
    protected Buttons buttons;



    public Politician(){
        //initialize base stats
        health = 100.0;
        maxHealth = health;
        attack = 1.0;
        defense = 1.0;
        speed = 100.0;
        precision = 1.0;
        evasion = 0.1;

        //initialize attacks
        attack1 = new Dmg("weak", "Attack 1");
        attack2 = new Dmg("weak", "Attack 2");
        attack3 = new Dmg("weak", "Attack 3");
        attack4 = new Dmg("weak", "Attack 4");
    }


    public Attack getAttack1(){
        return this.attack1;
    }

    public Attack getAttack2(){
        return this.attack2;
    }

    public Attack getAttack3(){
        return this.attack3;
    }

    public Attack getAttack4(){
        return this.attack4;
    }

    public HealthBar getHealthBar(){
        return this.healthBar;
    }

    public double getHealth(){
        //never return negative health
        // if (this.health < 0.0){
        //     return 0.0;
        // }
        return this.health;
    }
    public double getMaxHealth(){
        return this.maxHealth;
    }

    public String getName(){
        return "Politician";
    }

    public String getAttack1Name(){
        return this.attack1.getName();
    }

    public String getAttack2Name(){
        return this.attack2.getName();
    }

    public String getAttack3Name(){
        return this.attack3.getName();
    }

    public String getAttack4Name(){
        return this.attack4.getName();
    }

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("DonaldTrump.png"));
        } catch (IOException e){
        }
        return image;
    }
    public void setHealthBar(){
        this.healthBar = new HealthBar(this);
    }     
    public void setButtons(Combat combat){
        this.buttons = new Buttons(this, combat);
    }

    public void resetStats(){
        health = 100.0;
        maxHealth = health;
        attack = 1.0;
        defense = 1.0;
        speed = 100.0;
        precision = 1.0;
        evasion = 0.1;
    }

}
