import java.util.Random;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Grass extends GridObject{
    public BufferedImage image;
    // public String img = "grass";

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("Grass.png"));
        } catch (IOException e){
        }
        return image;
    }

    public String getName(){
        return "Grass";
    }
}
