import java.util.Random;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Player extends Politician {


    //Ideas for our Independent Character
    //small priority: take in name on game start, becomes your character's name
    //"Listen to the Will of the People" Medium Prs Raise
    //"Prepare a Plan" Strong Prs Raise
    //"Call Out Their Demagoguery" Enemy Def Lower Raise
    //"Orate The Truth!" (Strong Attack)

    
    private static final double PLAYER_MODIFIER = 1.4; //all of the parent class's stats except precision and evasion are scaled by this modifier for this class, making this character stronger

    public Player(){
        this.health = super.health * PLAYER_MODIFIER;
        this.maxHealth = health;
        this.attack = super.attack * PLAYER_MODIFIER;
        this.defense = super.defense * PLAYER_MODIFIER;
        this.speed = super.speed * PLAYER_MODIFIER;
        this.precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        this.evasion = super.evasion;

        attack1 = new Dmg("strong", "Orate the Truth");
        attack2 = new StatSelf("strong", "precision", "Develop a 4-Year Plan");
        attack3 = new StatEnemy("strong", "defense", "Call Out Their Demagoguery");
        attack4 = new StatSelf("strong", "attack", "Listen to the Will of the People");

    }

    //Non customizable.
    public String getName(){
        return "Candidate Alex";
    }

    public double getMaxHealth(){
        return maxHealth;
    }

    public BufferedImage getImage(){
        try {
            return image = ImageIO.read(new File("zuko.png"));
        } catch (IOException e){
        }
        return image;
    }

    public void setHealthBar(){
        this.healthBar = new HealthBar(this);
    } 
    
    public void setButtons(Combat combat){
        this.buttons = new Buttons(this, combat);
    }
    
    public void resetStats(){
        health = super.health * PLAYER_MODIFIER * 1.2;
        maxHealth = health;
        attack = super.attack * PLAYER_MODIFIER;
        defense = super.defense * PLAYER_MODIFIER;
        speed = super.speed * PLAYER_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;
    }

    // public void resetStats(){
    //     health = 100.0;
    //     maxHealth = health;
    //     attack = 1.0;
    //     defense = 1.0;
    //     speed = 100.0;
    //     precision = 1.0;
    //     evasion = 0.1;
    // }
}
