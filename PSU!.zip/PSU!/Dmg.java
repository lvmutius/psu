import java.awt.image.BufferedImage;

public class Dmg extends Attack {

    ///////////////////////
    //MODIFIERS EXPLAINED//
    ///////////////////////

    //All of the parent class's stats are scaled according to the chosen strength
    //of a given move. There are 3 kinds of strength: weak, medium, and strong.
    //When creating a move, the first String argument is the strength, and
    //that will determine which of the private static final modifiers below is used.
    //In damage-type moves, base damage is scaled by the modifier. In stat-type
    //moves, (stat-self or stat-enemy), the approprirate stat (indicated by arg 
    //#2 of the constructor, "stat") is used.

    private static final double WEAK_MODIFIER = 1.2; 
    private static final double MEDIUM_MODIFIER = 1.4;                       
    private static final double STRONG_MODIFIER = 1.6;
                                                    
    private static double modifier;
    private String name;

    public Dmg(String strength, String name) {

        this.name = name;
        isDamageType = true;

        if (strength == "weak")
            modifier = WEAK_MODIFIER;
        else if (strength == "medium")
            modifier = MEDIUM_MODIFIER;
        else if (strength == "strong")
            modifier = STRONG_MODIFIER;
        else { //catch errors
            System.out.println("ERROR: improperly formatted [strength argument] for move '" + name + "'");
        }
        baseDamage = super.baseDamage * modifier;
    }

    public String getName() {
        return name;
    }

    public boolean isDamageType() { //necessary?
        return isDamageType;
    }

    @Override
    public BufferedImage getImage() {
        // TODO Auto-generated method stub
        return null;
    }

}
