import javax.swing.JButton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * An action listener that prints a message.
 */
public class ButtonListener implements ActionListener {
    private JButton[] buttons; // 4 buttons
    public Politician politician; // set the politician
    public Attack attackSelected;
    public Combat combat;

    public ButtonListener(JButton[] buttons, Politician politician, Combat combat) {
        this.politician = politician;
        this.buttons = buttons;
        attackSelected = null;
        this.combat = combat;
    }
    public void actionPerformed(ActionEvent event) { // Same as in aiButtonListener

        if ((politician != combat.getTurn())){
            System.out.println("Not your turn!");
            return;
        }
        if (event.getSource() == buttons[0]) {
            combat.afterButtonClick(politician, politician.attack1);
            //for debugging
            System.out.println(politician.getAttack1Name());

        } else if (event.getSource() == buttons[1]) {
            combat.afterButtonClick(politician, politician.attack2);
            //for debugging
            System.out.println(politician.getAttack2Name());

        } else if (event.getSource() == buttons[2]) {
            combat.afterButtonClick(politician, politician.attack3);
            System.out.println(politician.getAttack3Name());

        } else if (event.getSource() == buttons[3]) {
            combat.afterButtonClick(politician, politician.attack4);
            System.out.println(politician.getAttack4Name());
        }
    }

    public Attack getAttackSelected(){
        return this.attackSelected;
    }
    
    public void nullifyAttackSelected(){
        this.attackSelected = null;
    }
}