import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;


public class arrowKeyListener extends PSUMain implements KeyListener {
    // static int playerX = 10;
    // static int playerY = 10;
    DrawingPanel panel;
    public static boolean inGame = true; 

    public arrowKeyListener (DrawingPanel panel) {
        this.panel = panel;
        
    }

    public void keyPressed(KeyEvent key) {
        if (key.getKeyCode() == KeyEvent.VK_ENTER) {


        }

        if((key.getKeyCode() == KeyEvent.VK_UP || key.getKeyCode() == KeyEvent.VK_KP_UP) && !checkUp().toString().contains("Rock")){
            osg.drawImage(getBackgroundImage(), 0, 0, WIDTH, HEIGHT, null);
            playerY--;
            try {
                checkFights();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
    

            if (inGame) {
                // osg.drawImage(player.getImage(), scaleToPanel(playerX), scaleToPanel(playerY), null);

                osg.drawImage(player.getImage(), playerX * cellPixelWidth, playerY * cellPixelHeight, cellPixelWidth, cellPixelHeight, null);

                g.drawImage(bg, 0, 0, null);

            }
            
        } else if ((key.getKeyCode() == KeyEvent.VK_DOWN || key.getKeyCode() == KeyEvent.VK_KP_DOWN) && !checkDown().toString().contains("Rock")) {
            osg.drawImage(getBackgroundImage(), 0, 0, WIDTH, HEIGHT, null);
            playerY++;
            try {
                checkFights();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


            if (inGame) {
                // osg.drawImage(player.getImage(), scaleToPanel(playerX), scaleToPanel(playerY), null);

                osg.drawImage(player.getImage(), playerX * cellPixelWidth, playerY * cellPixelHeight, cellPixelWidth, cellPixelHeight, null);

                g.drawImage(bg, 0, 0, null);
    
    
    
            }

        } else if ((key.getKeyCode() == KeyEvent.VK_LEFT || key.getKeyCode() == KeyEvent.VK_KP_LEFT) && !checkLeft().toString().contains("Rock")) {
            osg.drawImage(getBackgroundImage(), 0, 0, WIDTH, HEIGHT, null);
            playerX--;
            try {
                checkFights();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (inGame) {
                // osg.drawImage(player.getImage(), scaleToPanel(playerX), scaleToPanel(playerY), null);

                osg.drawImage(player.getImage(), playerX * cellPixelWidth, playerY * cellPixelHeight, cellPixelWidth, cellPixelHeight, null);
    
                g.drawImage(bg, 0, 0, null);
    
    
    
            }

        } else if ((key.getKeyCode() == KeyEvent.VK_RIGHT || key.getKeyCode() == KeyEvent.VK_KP_RIGHT) && !checkRight().toString().contains("Rock")) {
            osg.drawImage(getBackgroundImage(), 0, 0, WIDTH, HEIGHT, null);
            playerX++;

            try {
                checkFights();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (inGame) {
                // osg.drawImage(player.getImage(), scaleToPanel(playerX), scaleToPanel(playerY), null);
                
                osg.drawImage(player.getImage(), playerX * cellPixelWidth, playerY * cellPixelHeight, cellPixelWidth, cellPixelHeight, null);
    
                g.drawImage(bg, 0, 0, null);
    
    
    
            }

        }
       
    }

    @Override
    public void keyTyped(KeyEvent x) {
        throw new UnsupportedOperationException("Not in this program."); 
    }

    @Override
    public void keyReleased(KeyEvent key) {
        return;
        
    }
}