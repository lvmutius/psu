import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

public class enterKeyListener extends Combat implements KeyListener {
    Combat combat;
    
    public enterKeyListener (Combat combat) {
        super(combat.player, combat.p2, combat.frame, combat.commentator);
        this.combat = combat;

    }

    @Override
    public void keyTyped(KeyEvent e) {
        throw new UnsupportedOperationException("Not in this program.");
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        System.out.println("no bitches");
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            combat.frame.dispose();
            
        }
        
        
    }

    @Override
    public void keyReleased(KeyEvent e) {
        return;
        
    }
    

}
