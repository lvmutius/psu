public class Trump extends Politician {
 
    private static final double TRUMP_MODIFIER = 1.7; //all of the parent class's stats except precision and evasion are scaled by this modifier for this class, making this character stronger

    public Trump(){
        health = super.health * TRUMP_MODIFIER;
        attack = super.attack * TRUMP_MODIFIER;
        defense = super.defense * TRUMP_MODIFIER;
        speed = super.speed * TRUMP_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;

        attack1 = new Dmg("medium", "TWITTER RANT");
        attack2 = new StatSelf("medium", "defense", "Build the Wall");
        attack3 = new StatSelf("medium", "attack", "Incite the Proud Boys");
        attack4 = new StatEnemy("medium", "attack", "Call Fake News");
    }

    //Non customizable.
    public String getName(){
        return "Donald Trump";
    }

    public double getMaxHealth(){
        return this.maxHealth;
    }
    
    public void setHealthBar(){
        this.healthBar = new HealthBar(this);
    }     
    
    public void setButtons(Combat combat){
        this.buttons = new Buttons(this, combat);
    }
    public void resetStats(){
        health = super.health * TRUMP_MODIFIER;
        attack = super.attack * TRUMP_MODIFIER;
        defense = super.defense * TRUMP_MODIFIER;
        speed = super.speed * TRUMP_MODIFIER;
        precision = super.precision; //I think this line of code and the one below are not necessary, but keeping them here just to have all stats present.
        evasion = super.evasion;
    }
}